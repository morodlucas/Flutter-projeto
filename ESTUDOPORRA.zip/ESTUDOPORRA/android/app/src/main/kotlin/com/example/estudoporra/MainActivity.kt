package com.example.estudoporra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
